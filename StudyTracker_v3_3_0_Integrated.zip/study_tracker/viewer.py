from __future__ import annotations

from datetime import datetime, timedelta, timezone, date
import math
import json

from PySide6.QtCore import Qt, Signal, QRectF, QSize
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QFontMetrics
from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QPushButton,
    QComboBox,
    QLineEdit,
    QDateEdit,
    QCheckBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QSplitter,
    QGroupBox,
    QFormLayout,
    QAbstractItemView,
    QMessageBox,
    QFileDialog,
    QScrollArea,
    QSizePolicy,
)

from .analysis import (
    JST,
    Record,
    load_records,
    filter_records,
    daily_totals,
    aggregate_duration,
    calendar_totals,
    unique_values,
    stats,
    overlap_seconds,
)
from .models import COLUMNS, StudyRow
from .export import export_csv, export_xlsx


def fmt_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    return f"{seconds // 3600:02d}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}"


def fmt_short_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    if hours:
        return f"{hours}h {minutes:02d}m"
    return f"{minutes}m"


class BarChart(QWidget):
    barClicked = Signal(int, str)

    def __init__(self, orientation="vertical", parent=None):
        super().__init__(parent)
        self.orientation = orientation
        self.data: list[tuple[str, float]] = []
        self.setMinimumSize(420, 300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self._bars: list[QRectF] = []

    def setData(self, data: list[tuple[str, float]]):
        self.data = list(data)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), self.palette().base())
        if not self.data:
            painter.setPen(self.palette().text().color())
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "データなし")
            return

        left = 55
        right = 20
        top = 20
        bottom = 50
        plot = QRectF(left, top, max(10, self.width() - left - right), max(10, self.height() - top - bottom))
        max_value = max(v for _, v in self.data) or 1.0
        pen = QPen(self.palette().text().color())
        pen.setWidth(1)
        painter.setPen(pen)
        painter.drawLine(plot.left(), plot.bottom(), plot.right(), plot.bottom())
        self._bars = []

        fm = QFontMetrics(painter.font())
        n = len(self.data)
        if self.orientation == "vertical":
            slot = plot.width() / max(1, n)
            bar_w = max(8, slot * 0.62)
            for i, (label, value) in enumerate(self.data):
                h = plot.height() * value / max_value
                x = plot.left() + slot * i + (slot - bar_w) / 2
                y = plot.bottom() - h
                rect = QRectF(x, y, bar_w, h)
                self._bars.append(rect)
                painter.fillRect(rect, self.palette().highlight())
                painter.setPen(pen)
                painter.drawText(QRectF(x - 10, plot.bottom() + 5, slot + 20, 22), Qt.AlignmentFlag.AlignCenter, label)
                painter.drawText(QRectF(x - 20, y - 20, bar_w + 40, 18), Qt.AlignmentFlag.AlignCenter, fmt_short_duration(value))
        else:
            slot = plot.height() / max(1, n)
            bar_h = max(10, slot * 0.62)
            for i, (label, value) in enumerate(self.data):
                w = plot.width() * value / max_value
                y = plot.top() + slot * i + (slot - bar_h) / 2
                rect = QRectF(plot.left(), y, w, bar_h)
                self._bars.append(rect)
                painter.fillRect(rect, self.palette().highlight())
                painter.setPen(pen)
                label_rect = QRectF(2, y, left - 8, bar_h)
                painter.drawText(label_rect, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, label)
                painter.drawText(QRectF(plot.left() + w + 5, y, 90, bar_h), Qt.AlignmentFlag.AlignVCenter, fmt_short_duration(value))

    def mousePressEvent(self, event):
        pos = event.position()
        for i, rect in enumerate(self._bars):
            if rect.contains(pos.toPoint()):
                label = self.data[i][0]
                self.barClicked.emit(i, label)
                return


class DailyChart(QWidget):
    dayClicked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data: list[tuple[date, float]] = []
        self._points: list[tuple[QRectF, date]] = []
        self.setMinimumHeight(300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def setData(self, data):
        self.data = list(data)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), self.palette().base())
        if not self.data:
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "データなし")
            return

        plot = QRectF(55, 20, max(20, self.width() - 75), max(20, self.height() - 60))
        max_v = max(v for _, v in self.data) or 1
        painter.setPen(self.palette().text().color())
        painter.drawLine(plot.left(), plot.bottom(), plot.right(), plot.bottom())
        painter.drawLine(plot.left(), plot.top(), plot.left(), plot.bottom())

        points = []
        self._points = []
        n = len(self.data)
        for i, (day, value) in enumerate(self.data):
            x = plot.left() if n == 1 else plot.left() + plot.width() * i / (n - 1)
            y = plot.bottom() - plot.height() * value / max_v
            points.append((x, y))
            r = QRectF(x - 7, y - 7, 14, 14)
            self._points.append((r, day))

        pen = QPen(self.palette().highlight())
        pen.setWidth(2)
        painter.setPen(pen)
        for i in range(1, len(points)):
            painter.drawLine(points[i - 1][0], points[i - 1][1], points[i][0], points[i][1])
        painter.setBrush(QBrush(self.palette().highlight()))
        for i, (x, y) in enumerate(points):
            painter.drawEllipse(QRectF(x - 4, y - 4, 8, 8))
            if i == 0 or i == n - 1 or n <= 10 or i % max(1, n // 8) == 0:
                label = self.data[i][0].strftime("%m/%d")
                painter.drawText(QRectF(x - 28, plot.bottom() + 5, 56, 20), Qt.AlignmentFlag.AlignCenter, label)

    def mousePressEvent(self, event):
        p = event.position()
        for rect, day in self._points:
            if rect.contains(p.toPoint()):
                self.dayClicked.emit(day)
                return


class CalendarHeatmap(QWidget):
    dayClicked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.values: dict[date, float] = {}
        self.start: date | None = None
        self.end: date | None = None
        self.setMinimumHeight(300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._cells: list[tuple[QRectF, date]] = []

    def setData(self, values, start, end):
        self.values = values
        self.start = start
        self.end = end
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), self.palette().base())
        self._cells = []
        if not self.start or not self.end:
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "データなし")
            return

        start = self.start
        monday = start - timedelta(days=start.weekday())
        end = self.end
        weeks = max(1, math.ceil((end - monday).days / 7))
        cell_w = max(13.0, (self.width() - 45) / weeks)
        cell_h = 22.0
        max_v = max(self.values.values(), default=0.0) or 1.0
        palette = [self.palette().base().color().lighter(100 + i * 10) for i in range(5)]

        painter.setPen(self.palette().text().color())
        for weekday, label in enumerate(["月", "火", "水", "木", "金", "土", "日"]):
            painter.drawText(QRectF(2, 15 + weekday * cell_h, 28, 18), Qt.AlignmentFlag.AlignCenter, label)

        day = monday
        while day <= end:
            week = (day - monday).days // 7
            row = day.weekday()
            x = 35 + week * cell_w
            y = 15 + row * cell_h
            value = self.values.get(day, 0.0)
            if value <= 0:
                color = self.palette().alternateBase().color()
            else:
                ratio = min(1.0, value / max_v)
                idx = min(4, max(1, int(ratio * 4) + 1))
                color = palette[idx]
            rect = QRectF(x, y, max(10.0, cell_w - 3), cell_h - 3)
            painter.fillRect(rect, color)
            painter.drawRect(rect)
            self._cells.append((rect, day))
            day += timedelta(days=1)

    def mousePressEvent(self, event):
        p = event.position()
        for rect, day in self._cells:
            if rect.contains(p.toPoint()):
                self.dayClicked.emit(day)
                return


class MetricCard(QGroupBox):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        self.title = QLabel(title)
        self.title.setStyleSheet("font-weight: bold;")
        self.value = QLabel("-")
        self.value.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(self.title)
        layout.addWidget(self.value)

    def setValue(self, value):
        self.value.setText(value)


class RecordDetailDialog(QMainWindow):
    def __init__(self, record: Record, duration: float, parent=None):
        super().__init__(parent)
        self.setWindowTitle("学習記録詳細")
        self.resize(620, 520)
        root = QWidget()
        layout = QFormLayout(root)
        pairs = [
            ("セッション", str(record.session_id)),
            ("開始", record.start.astimezone(JST).strftime("%Y-%m-%d %H:%M:%S")),
            ("終了", record.end.astimezone(JST).strftime("%Y-%m-%d %H:%M:%S")),
            ("時間", fmt_duration(duration)),
            ("Active", "Yes" if record.active else "No"),
            ("学習区分", record.category),
            ("科目", record.subject),
            ("教材", record.material),
            ("学習位置", record.position),
            ("学習単位", record.unit),
            ("学習範囲", record.scope),
            ("備考", "\n".join(record.notes)),
        ]
        for label, value in pairs:
            value_label = QLabel(value or "(未設定)")
            value_label.setWordWrap(True)
            layout.addRow(label, value_label)
        self.setCentralWidget(root)


class ViewerWindow(QMainWindow):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.records = load_records(db)
        self.setWindowTitle("Study Tracker V3.0 — 学習記録ビューアー")
        self.resize(1500, 930)
        self._detail_windows = []
        self._build()
        self._reload_filters()
        self._period_changed(self.period.currentText())
        self._refresh()

    def _build(self):
        root = QWidget()
        root_layout = QVBoxLayout(root)

        filter_box = QGroupBox("フィルター")
        filters = QGridLayout(filter_box)

        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.period = QComboBox()
        self.period.addItems(["直近7日", "直近30日", "今月", "全期間", "カスタム"])
        self.period.currentTextChanged.connect(self._period_changed)
        self.category = QComboBox()
        self.subject = QComboBox()
        self.material = QComboBox()
        self.query = QLineEdit()
        self.query.setPlaceholderText("科目・教材・学習位置・備考など")
        self.active_only = QCheckBox("Active区間のみ")
        self.active_only.setChecked(True)
        self.apply_button = QPushButton("更新")
        self.apply_button.clicked.connect(self._refresh)

        filters.addWidget(QLabel("期間"), 0, 0)
        filters.addWidget(self.period, 0, 1)
        filters.addWidget(QLabel("開始"), 0, 2)
        filters.addWidget(self.start_date, 0, 3)
        filters.addWidget(QLabel("終了"), 0, 4)
        filters.addWidget(self.end_date, 0, 5)
        filters.addWidget(QLabel("学習区分"), 1, 0)
        filters.addWidget(self.category, 1, 1)
        filters.addWidget(QLabel("科目"), 1, 2)
        filters.addWidget(self.subject, 1, 3)
        filters.addWidget(QLabel("教材"), 1, 4)
        filters.addWidget(self.material, 1, 5)
        filters.addWidget(QLabel("検索"), 2, 0)
        filters.addWidget(self.query, 2, 1, 1, 4)
        filters.addWidget(self.active_only, 2, 5)
        filters.addWidget(self.apply_button, 0, 6, 3, 1)

        root_layout.addWidget(filter_box)

        self.tabs = QTabWidget()
        self.dashboard_tab = self._build_dashboard()
        self.history_tab = self._build_history()
        self.content_tab = self._build_content_analysis()
        root_layout.addWidget(self.tabs)

        self.setCentralWidget(root)

    def _build_dashboard(self):
        tab = QWidget()
        outer = QVBoxLayout(tab)
        outer.setContentsMargins(6, 6, 6, 6)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        canvas = QWidget()
        root = QVBoxLayout(canvas)
        root.setContentsMargins(4, 4, 12, 12)
        root.setSpacing(10)

        cards = QHBoxLayout()
        self.card_total = MetricCard("総学習時間")
        self.card_days = MetricCard("学習日数")
        self.card_sessions = MetricCard("セッション数")
        self.card_average = MetricCard("平均セクション")
        self.card_longest = MetricCard("最長セクション")
        for card in [self.card_total, self.card_days, self.card_sessions, self.card_average, self.card_longest]:
            cards.addWidget(card, 1)
        root.addLayout(cards)

        daily_group = QGroupBox("日別学習時間")
        dl = QVBoxLayout(daily_group)
        self.daily_chart = DailyChart()
        self.daily_chart.setMinimumHeight(320)
        self.daily_chart.dayClicked.connect(self._focus_day)
        dl.addWidget(self.daily_chart)

        grid = QGridLayout()
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        grid.setRowStretch(0, 1)
        grid.setRowStretch(1, 1)

        subject_group = QGroupBox("科目別学習時間")
        sl = QVBoxLayout(subject_group)
        self.subject_chart = BarChart(orientation="horizontal")
        sl.addWidget(self.subject_chart)
        self.subject_chart.barClicked.connect(self._focus_subject)

        material_group = QGroupBox("教材別学習時間")
        ml = QVBoxLayout(material_group)
        self.material_chart = BarChart(orientation="horizontal")
        ml.addWidget(self.material_chart)
        self.material_chart.barClicked.connect(self._focus_material)

        calendar_group = QGroupBox("学習カレンダー")
        cl = QVBoxLayout(calendar_group)
        self.calendar = CalendarHeatmap()
        cl.addWidget(self.calendar)
        self.calendar.dayClicked.connect(self._focus_day)

        grid.addWidget(daily_group, 0, 0, 1, 2)
        grid.addWidget(subject_group, 1, 0)
        grid.addWidget(material_group, 1, 1)
        grid.addWidget(calendar_group, 2, 0, 1, 2)
        root.addLayout(grid)

        root.addStretch(1)
        scroll.setWidget(canvas)
        outer.addWidget(scroll, 1)
        return tab

    def _build_history(self):
        tab = QWidget()
        root = QVBoxLayout(tab)
        toolbar = QHBoxLayout()
        self.export_csv_button = QPushButton("表示中をCSV")
        self.export_csv_button.clicked.connect(self._export_csv)
        self.export_xlsx_button = QPushButton("表示中をXLSX")
        self.export_xlsx_button.clicked.connect(self._export_xlsx)
        self.history_count = QLabel()
        toolbar.addWidget(self.history_count)
        toolbar.addStretch()
        toolbar.addWidget(self.export_csv_button)
        toolbar.addWidget(self.export_xlsx_button)
        root.addLayout(toolbar)

        self.history_table = QTableWidget()
        self.history_table.setColumnCount(len(COLUMNS) + 4)
        self.history_table.setHorizontalHeaderLabels(COLUMNS + ["時間", "Session", "Segment", "Active"])
        self.history_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.history_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.history_table.doubleClicked.connect(self._open_detail)
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        root.addWidget(self.history_table)
        return tab

    def _build_content_analysis(self):
        tab = QWidget()
        root = QVBoxLayout(tab)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        canvas = QWidget()
        layout = QVBoxLayout(canvas)

        position_group = QGroupBox("学習位置別学習時間")
        pl = QVBoxLayout(position_group)
        self.position_chart = BarChart(orientation="horizontal")
        pl.addWidget(self.position_chart)
        position_group.setMinimumHeight(360)

        unit_group = QGroupBox("学習単位別学習時間")
        ul = QVBoxLayout(unit_group)
        self.unit_chart = BarChart(orientation="horizontal")
        ul.addWidget(self.unit_chart)
        unit_group.setMinimumHeight(360)

        layout.addWidget(position_group)
        layout.addWidget(unit_group)
        layout.addStretch(1)
        scroll.setWidget(canvas)
        root.addWidget(scroll)
        return tab

    def _reload_filters(self):
        categories = sorted({r.category for r in self.records if r.category}, key=str.casefold)
        subjects = sorted({r.subject for r in self.records if r.subject}, key=str.casefold)
        materials = sorted({r.material for r in self.records if r.material}, key=str.casefold)

        for combo, values in [
            (self.category, categories),
            (self.subject, subjects),
            (self.material, materials),
        ]:
            combo.blockSignals(True)
            combo.clear()
            combo.addItem("すべて")
            combo.addItems(values)
            combo.blockSignals(False)

        if self.records:
            mn = min(r.start.astimezone(JST).date() for r in self.records)
            mx = max(r.end.astimezone(JST).date() for r in self.records)
        else:
            now = datetime.now(JST).date()
            mn = mx = now
        self.start_date.setDate(datetime.combine(mn, datetime.min.time()).date())
        self.end_date.setDate(datetime.combine(mx, datetime.min.time()).date())

    def _period_changed(self, value):
        today = datetime.now(JST).date()
        if value == "直近7日":
            start = today - timedelta(days=6)
            end = today
        elif value == "直近30日":
            start = today - timedelta(days=29)
            end = today
        elif value == "今月":
            start = today.replace(day=1)
            next_month = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
            end = next_month - timedelta(days=1)
        elif value == "全期間":
            if self.records:
                start = min(r.start.astimezone(JST).date() for r in self.records)
                end = max(r.end.astimezone(JST).date() for r in self.records)
            else:
                start = end = today
        else:
            return
        self.start_date.setDate(start)
        self.end_date.setDate(end)

    def _date_window(self):
        start_d = self.start_date.date().toPython()
        end_d = self.end_date.date().toPython()
        start = datetime(start_d.year, start_d.month, start_d.day, tzinfo=JST)
        end = datetime(end_d.year, end_d.month, end_d.day, tzinfo=JST) + timedelta(days=1)
        return start, end

    def _filtered(self):
        start, end = self._date_window()
        category = "" if self.category.currentText() == "すべて" else self.category.currentText()
        subject = "" if self.subject.currentText() == "すべて" else self.subject.currentText()
        material = "" if self.material.currentText() == "すべて" else self.material.currentText()
        return filter_records(
            self.records,
            start=start,
            end=end,
            category=category,
            subject=subject,
            material=material,
            query=self.query.text(),
            active_only=self.active_only.isChecked(),
        )

    def _refresh(self):
        start, end = self._date_window()
        records = self._filtered()
        summary = stats(records, start, end)
        self.card_total.setValue(fmt_duration(summary["total"]))
        self.card_days.setValue(f'{summary["study_days"]}日')
        self.card_sessions.setValue(f'{summary["sessions"]}')
        self.card_average.setValue(fmt_short_duration(summary["average"]))
        self.card_longest.setValue(fmt_duration(summary["longest"]))

        self.daily_chart.setData(daily_totals(records, start, end))
        self.subject_chart.setData(aggregate_duration(records, key=lambda r: r.subject)[:12])
        self.material_chart.setData(aggregate_duration(records, key=lambda r: r.material)[:12])
        self.position_chart.setData(aggregate_duration(records, key=lambda r: r.position)[:15])
        self.unit_chart.setData(aggregate_duration(records, key=lambda r: r.unit)[:15])
        self.calendar.setData(calendar_totals(records, start, end), start.date(), end.date() - timedelta(days=1))

        self._fill_history(records, start, end)
        self.history_count.setText(f"表示 {len(records)} セグメント")

    def _fill_history(self, records, start, end):
        self.history_table.setRowCount(len(records))
        for i, record in enumerate(records):
            duration = overlap_seconds(record, start, end)
            values = [
                record.start.astimezone(JST).strftime("%Y.%m.%d"),
                record.start.astimezone(JST).strftime("%H:%M:%S"),
                record.end.astimezone(JST).strftime("%H:%M:%S"),
                "Asia/Tokyo",
                record.category,
                record.subject,
                record.material,
                record.position,
                record.unit,
                record.scope,
                "\n".join(record.notes),
                fmt_duration(duration),
                str(record.session_id),
                str(record.segment_id),
                "Yes" if record.active else "No",
            ]
            for j, value in enumerate(values):
                self.history_table.setItem(i, j, QTableWidgetItem(value))

    def _focus_day(self, day):
        self.start_date.setDate(day)
        self.end_date.setDate(day)
        self.period.setCurrentText("カスタム")
        self._refresh()
        self.tabs.setCurrentWidget(self.dashboard_tab)

    def _focus_subject(self, _index, label):
        self.subject.setCurrentText(label)
        self._refresh()
        self.tabs.setCurrentWidget(self.dashboard_tab)

    def _focus_material(self, _index, label):
        self.material.setCurrentText(label)
        self._refresh()
        self.tabs.setCurrentWidget(self.dashboard_tab)

    def _open_detail(self):
        row = self.history_table.currentRow()
        if row < 0:
            return
        segment_id_item = self.history_table.item(row, len(COLUMNS) + 2)
        if not segment_id_item:
            return
        segment_id = int(segment_id_item.text())
        record = next((r for r in self._filtered() if r.segment_id == segment_id), None)
        if record is None:
            return
        start, end = self._date_window()
        duration = overlap_seconds(record, start, end)
        dlg = RecordDetailDialog(record, duration, self)
        dlg.show()
        self._detail_windows.append(dlg)

    def _filtered_rows_for_export(self):
        start, end = self._date_window()
        records = self._filtered()
        rows = []
        for record in records:
            rows.append(StudyRow(
                date=record.start.astimezone(JST).strftime("%Y.%m.%d"),
                start=record.start.astimezone(JST).strftime("%H:%M:%S.%f")[:-4],
                end=record.end.astimezone(JST).strftime("%H:%M:%S.%f")[:-4],
                timezone="Asia/Tokyo",
                category=record.category,
                subject=record.subject,
                material=record.material,
                position=record.position,
                unit=record.unit,
                scope=record.scope,
                notes=list(record.notes),
                branch_fields=set(record.branch_fields),
            ))
        return rows

    def _export_csv(self):
        path, _ = QFileDialog.getSaveFileName(self, "CSV出力", "viewer.csv", "CSV (*.csv)")
        if not path:
            return
        rows = self._filtered_rows_for_export()
        export_csv(rows, path)

    def _export_xlsx(self):
        path, _ = QFileDialog.getSaveFileName(self, "XLSX出力", "viewer.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        rows = self._filtered_rows_for_export()
        export_xlsx(rows, self.db.aliases(), path)
