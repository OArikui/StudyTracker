from __future__ import annotations
from pathlib import Path
import json
import os

APP_CONFIG_DIR = Path(os.environ.get("APPDATA", Path.home())) / "StudyTracker"
CONFIG_PATH = APP_CONFIG_DIR / "config.json"
DEFAULT_DATA_DIR = Path.home() / "StudyTracker"
DEFAULT_DB_PATH = DEFAULT_DATA_DIR / "study_tracker.sqlite3"


def load_config() -> dict:
    APP_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_PATH.exists():
        return {"db_path": str(DEFAULT_DB_PATH)}
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError
        return data
    except Exception:
        return {"db_path": str(DEFAULT_DB_PATH)}


def save_config(data: dict) -> None:
    APP_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def get_db_path() -> Path:
    cfg = load_config()
    return Path(cfg.get("db_path", str(DEFAULT_DB_PATH))).expanduser()


def set_db_path(path: str | Path) -> None:
    cfg = load_config()
    cfg["db_path"] = str(Path(path).expanduser())
    save_config(cfg)
