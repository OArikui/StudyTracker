from __future__ import annotations

import sys
from PySide6.QtWidgets import QApplication

from .ui import ViewerWindow


def run(database_path=None) -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("StudyTracker ViewerV0")
    window = ViewerWindow(database_path=database_path)
    window.show()
    return app.exec()
