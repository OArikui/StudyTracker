# StudyTracker

StudyTracker 本体と Viewer を統合した Python / PySide6 アプリです。

## 起動

```powershell
python -m pip install -r requirements.txt
python .\\main.py
```

Viewer を起動する場合:

```powershell
python .\\main.py --viewer
python .\\main.py --viewer-zip E:\\path\\StudyTrackerViewer_v0_8_0.zip
```

`--viewer-zip` は追加パッケージ ZIP のパスを検証し、同梱 Viewer を起動します。Viewer は StudyTracker 本体の `%APPDATA%/StudyTracker/config.json` の `db_path` に完全に従います。

## 保存形式

SQLite のテーブル構造、`segments.row_json` の正規キー、日時形式、互換キー、バックアップ方法は [保存形式リファレンス](docs/保存形式リファレンス.md) を参照してください。

## バージョン

統合パッケージ: **StudyTracker 3.3.0** / Viewer Add-on **0.9.0**


## プリセット登録の注意

学習単位エイリアスは、**Docstringが空欄のままでは登録できません**。各エイリアスの意味を Docstring に記入してください。
