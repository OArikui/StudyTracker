from __future__ import annotations
import argparse
import os
import sys
import zipfile
from pathlib import Path


def _launch_viewer(zip_path: str | None) -> int:
    from study_tracker.paths import get_db_path
    db_path = get_db_path().expanduser().resolve()
    if not db_path.is_file():
        raise FileNotFoundError(f"StudyTracker本体の設定DBが見つかりません: {db_path}")
    if zip_path:
        addon = Path(zip_path).expanduser().resolve()
        if not addon.is_file() or not zipfile.is_zipfile(addon):
            raise ValueError(f"Viewer追加パッケージZIPではありません: {addon}")
        with zipfile.ZipFile(addon) as archive:
            names = set(archive.namelist())
            if not any(name.startswith("viewer_v0/") for name in names):
                raise ValueError("ZIP内に viewer_v0/ パッケージがありません。")
    os.environ["STUDYTRACKER_DB_PATH"] = str(db_path)
    from viewer_v0.app import run
    return run(database_path=db_path)


def main() -> int:
    parser = argparse.ArgumentParser(description="StudyTracker")
    parser.add_argument("--viewer-zip", help="Viewer追加パッケージZIPのパスを指定して起動")
    args, remaining = parser.parse_known_args()
    if args.viewer_zip:
        return _launch_viewer(args.viewer_zip)
    if "--viewer" in remaining:
        return _launch_viewer(None)
    from study_tracker.app import run
    return run()

if __name__ == "__main__":
    raise SystemExit(main())
