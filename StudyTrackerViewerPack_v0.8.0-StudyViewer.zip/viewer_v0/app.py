from __future__ import annotations

import sys
from PySide6.QtWidgets import QApplication

from .ui import ViewerWindow


def run() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("StudyTracker ViewerV0")
    window = ViewerWindow()
    window.show()
    return app.exec()
