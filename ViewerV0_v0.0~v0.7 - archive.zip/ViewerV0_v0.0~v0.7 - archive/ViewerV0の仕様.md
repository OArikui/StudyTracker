作成しました。既存の `StudyTracker` とは完全に分離した独立ソフト **StudyTracker ViewerV0** です。

[ViewerV0.zip をダウンロード](sandbox:/mnt/data/ViewerV0.zip)

### ViewerV0の仕様

* **StudyTracker本体のコードを読み込まない独立アプリ**

* StudyTrackerのSQLite DBを**読み取り専用**で開く

* `%APPDATA%\StudyTracker\config.json` のDB設定を自動検出

* DBをGUIから手動選択可能

* StudyTracker本体のDBへ `INSERT / UPDATE / DELETE` を行わない

* 期間フィルター
  
  * 直近7日
  * 直近30日
  * 今月
  * 全期間

* 学習区分・科目・教材で絞り込み

* キーワード検索

* Active / Passive絞り込み

* 集計表示
  
  * 総勉強時間
  * 学習日数
  * セッション数
  * 区間数
  * 平均区間
  * 最長区間

* グラフ
  
  * 日別勉強時間
  * 科目別勉強時間
  * 教材別勉強時間

* 学習記録一覧

* ダブルクリックによる詳細表示

* 表示中データのCSV出力

### 起動

展開後、

```powershell
cd E:\active\ViewerV0
python -m pip install -r requirements.txt
python main.py
```

で起動できます。

テストも実施しており、**3 tests passed**、Pythonコンパイルチェックも成功しています。

今回はまず **「StudyTrackerのデータを見るためだけの独立ビューアー」** としてV0を構成しています。
